# X-VOID Auto Aim Lab (Android)

Ini adalah aplikasi demo/simulator kontrol bidikan untuk game buatan sendiri.
Aplikasi tidak membaca, menyuntik, atau mengubah memori Free Fire dan tidak mengendalikan game lain.

## Build APK lewat HP dengan Codemagic

1. Ekstrak ZIP ini.
2. Upload seluruh isi folder proyek ke repository GitHub baru.
3. Buka Codemagic, login dengan GitHub, lalu beri akses ke repository tersebut.
4. Pilih repository `XVoidAutoAim`.
5. Jalankan workflow `android-xvoid` dari file `codemagic.yaml`.
6. Setelah build selesai, buka bagian Artifacts dan unduh file APK.

APK yang dihasilkan adalah APK debug untuk instalasi/testing Android.
