package com.xvoid.autoaim;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private boolean enabled = false;
    private TextView status;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(9, 9, 13));

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(34), dp(22), dp(28));
        scroll.addView(page);

        TextView brand = text("X-VOID", 30, Color.rgb(255, 55, 72));
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        page.addView(brand);

        TextView subtitle = text("AUTO AIM LAB  /  ANDROID SIMULATOR", 11, Color.LTGRAY);
        subtitle.setPadding(0, dp(4), 0, dp(24));
        page.addView(subtitle);

        TextView warning = text(
            "SIMULATOR MODE\nAplikasi ini hanya demo kontrol bidikan untuk proyek/game buatan sendiri. " +
            "Tidak terhubung ke Free Fire atau aplikasi lain.",
            13, Color.WHITE);
        warning.setPadding(dp(14), dp(14), dp(14), dp(14));
        warning.setBackgroundColor(Color.rgb(35, 22, 28));
        page.addView(warning);

        TextView heading = text("CONTROL PANEL", 17, Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setPadding(0, dp(26), 0, dp(12));
        page.addView(heading);

        status = text("STATUS: OFF", 16, Color.rgb(255, 100, 110));
        status.setTypeface(Typeface.DEFAULT_BOLD);
        status.setPadding(0, dp(8), 0, dp(12));
        page.addView(status);

        Button toggle = new Button(this);
        toggle.setText("TOGGLE SIMULATION");
        toggle.setOnClickListener(v -> {
            enabled = !enabled;
            status.setText(enabled ? "STATUS: ON — SIMULASI AKTIF" : "STATUS: OFF");
            status.setTextColor(enabled ? Color.rgb(100, 230, 150) : Color.rgb(255, 100, 110));
        });
        page.addView(toggle);

        addSlider(page, "AIM SPEED", 1, 20, 7);
        addSlider(page, "SENSITIVITY", 1, 100, 50);
        addSlider(page, "TARGET RANGE (SIMULASI)", 5, 100, 30);

        TextView demo = text(
            "TARGET PREVIEW\n\n[ ● ]  Dummy target\n\n" +
            "Status target: menunggu simulasi\nTracking: hanya tampilan demo",
            14, Color.WHITE);
        demo.setPadding(dp(14), dp(18), dp(14), dp(18));
        demo.setBackgroundColor(Color.rgb(24, 24, 31));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(24);
        page.addView(demo, p);

        TextView footer = text("X-VOID // BUILD 1.0", 10, Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(26), 0, 0);
        page.addView(footer);

        setContentView(scroll);
    }

    private void addSlider(LinearLayout parent, String label, int min, int max, int initial) {
        TextView title = text(label, 13, Color.LTGRAY);
        title.setPadding(0, dp(20), 0, dp(4));
        parent.addView(title);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(initial - min);
        parent.addView(bar);

        TextView value = text("VALUE: " + initial, 12, Color.WHITE);
        parent.addView(value);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value.setText("VALUE: " + (progress + min));
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }
}
